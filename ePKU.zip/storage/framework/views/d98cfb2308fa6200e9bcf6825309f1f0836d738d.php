

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div>
        <div class="card shadow-sm" style="min-height: 70vh;">
            <div class="card-header text-white d-flex align-items-center justify-content-between">
                <h5>Edit Medical Staff Details</h5>
                <?php echo $__env->make('partials.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include the tabs partial -->
            </div>

            <div class="card-body p-4">
                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(session('success')): ?>
                    <!-- Display success message -->
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.updateMedStaff', ['medStaffId' => $medStaff->msID])); ?>" onsubmit="return confirm('Are you sure you want to update this user?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <!-- Add input fields for editing medical staff details -->
                    <div class="row gy-3">
                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" value="<?php echo e(old('name', $medStaff->name)); ?>">
                                <label for="name">Name</label>
                            </div>

                            <div class="form-floating mb-3">
                                <select class="form-select" id="gender" name="gender">
                                    <option value="Male" <?php echo e(old('gender', $medStaff->gender) == 'Male' ? 'selected' : ''); ?>>Male</option>
                                    <option value="Female" <?php echo e(old('gender', $medStaff->gender) == 'Female' ? 'selected' : ''); ?>>Female</option>
                                </select>
                                <label for="gender">Gender</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo e(old('email', $medStaff->email)); ?>">
                                <label for="email">Email</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="phone_number" name="phone_number" placeholder="Enter phone number" value="<?php echo e(old('phone_number', $medStaff->phone_number)); ?>">
                                <label for="phone_number">Phone Number</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="position" name="position" placeholder="Enter position" value="<?php echo e(old('position', $medStaff->position)); ?>">
                                <label for="position">Position</label>
                            </div>

                            <div class="form-floating mb-3">
                                <select class="form-select" id="department" name="department_id">
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->department_id); ?>" <?php echo e(old('department_id', $medStaff->department_id) == $department->department_id ? 'selected' : ''); ?>><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="department">Department</label>
                            </div>

                            <div class="form-floating mb-3">
                                <select class="form-select" id="unit" name="unit_id">
                                    <option value="">Select Unit</option>
                                    <option value="">No Associated Unit</option>
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->unit_id); ?>" <?php echo e(old('unit_id', $medStaff->unit_id) == $unit->unit_id ? 'selected' : ''); ?>><?php echo e($unit->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="unit">Unit</label>
                            </div>

                            <div class="form-floating mb-3">
                                <select class="form-select" id="active" name="active">
                                    <option value="1" <?php echo e($medStaff->active == 1 ? 'selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e($medStaff->active == 0 ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                                <label for="active">Status</label>
                            </div>

                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update
                        </button>
                        <a href="<?php echo e(route('admin.medStaffDetails', ['medStaffId' => $medStaff->msID])); ?>" class="btn btn-secondary" onclick="return confirmCancellation()">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Function to handle the cancellation confirmation
    function confirmCancellation() {
        return confirm('Are you sure you want to cancel updating this staff member?');
    }

    // Function to set the active tab based on the current URL
    $(document).ready(function () {
        var currentPath = window.location.pathname;
        if (currentPath.includes('/admin/medStaff/')) {
            $('.nav-link[data-tab="manageMedStaff"]').addClass('active');
        } else {
            $('.nav-link').each(function () {
                var link = $(this).attr('href');
                if (currentPath === link) {
                    $(this).addClass('active');
                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ePKU\resources\views\admin\med-staff-edit.blade.php ENDPATH**/ ?>