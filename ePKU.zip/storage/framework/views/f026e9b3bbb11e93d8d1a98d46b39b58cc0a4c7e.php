<?php $__env->startSection('content'); ?>
<style>
    body {
        background-image: url('<?php echo e(asset('img/bg_epku.png')); ?>'), linear-gradient(rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5));
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-position: center;
        background-color: #d8dff1;
    }
    .fixed-width {
    width: 1200px; /* Adjust the width as needed */
    }
</style>
<div class="container login-page mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow-sm fixed-width">
                <div class="card-header" style="background-color: #036EB8; color: white;">
                    <h4 class="text-center"><?php echo e(__('Admin Login')); ?></h4>
                </div>

                <div class="card-body p-4">
                <?php if(session('status')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('admin.login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="username" class="form-label"><?php echo e(__('Username')); ?></label>
                            <input id="username" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label"><?php echo e(__('Password')); ?></label>
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-block">
                                <?php echo e(__('Login')); ?>

                            </button>
                        </div>

                        <?php if(Route::has('password.request')): ?>
                            <div class="text-center mt-3">
                                <a class="text-decoration-none" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            </div>
                        <?php endif; ?>
                        <?php if(auth()->guard()->guest()): ?>
                        
                        <div class="text-center">
                            <h4 class="mb-4">Login as Admin</h4>
                            <a href="<?php echo e(route('admin.login')); ?>" class="btn btn-secondary btn-lg">Login</a>
                        </div>
                    <?php else: ?>
                        
                        <div class="text-center">
                            <h4 class="mb-4">Welcome, <?php echo e(Auth::user()->name); ?></h4>
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary btn-lg mb-3">Go to Admin Dashboard</a>
                            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-lg">Logout</button>
                            </form>
                        </div>
                    <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ePKU\resources\views\welcome-admin.blade.php ENDPATH**/ ?>