<div class="container">
    <!-- Display announcements, reminder, and operating hours -->
    <div class="row">
        <!-- Announcements -->
        <div class="col-md-3">
            <div class="text-center">
                <hr>
                <h5><strong>Announcements</strong></h5>
                <hr>
                <?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <?php if($announcement->visible): ?>
                        <div>
                            <h5><strong><?php echo e($announcement->title); ?></strong></h5>
                            <p><?php echo e($announcement->content); ?></p>
                        </div>
                        <hr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No announcements available.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Reminder -->
        <div class="col-md-3">
            <div style="text-align: center;">
                <hr>
                <h5><strong>Reminder</strong></h5>
                <hr>
                <p>Upon visiting PKU for your appointment, do remember to:</p>
                <p>📌 Bring along your Matric Card/Staff card</p>
                <p>📌 Wear a face mask</p>
            </div>
        </div>

        <!-- Medical Operating Hours -->
        <div class="col-md-3">
            <div style="text-align: center;">
                <hr>
                <h5><strong>Medical Operating Hours</strong></h5>
                <hr>
                <h6><strong>Medical Operating Hours</strong></h6>
                <p>📌 Sunday - Wednesday: 8.00 AM - 7.30 PM</p>
                <p>📌 Thursday: 8.00 AM - 6.00 PM</p>
            </div>
        </div>

        <!-- Dental Operating Hours -->
        <div class="col-md-3">
            <div style="text-align: center;">
                <hr>
                <h5><strong>Dental Operating Hours</strong></h5>
                <hr>
                <h6><strong>Dental Operating Hours</strong></h6>
                <p>📌 Sunday - Wednesday: 8.00 AM - 5.00 PM</p>
                <p>📌 Thursday: 8.00 AM - 3.30 PM</p>
            </div>
        </div>
    </div>
</div>


<!-- Full-Width Announcement Section -->
<div class="col-md-11 mx-auto">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0"><strong><?php echo e(__('Announcements & Updates')); ?></strong></h4>
                </div>
                <div class="card-body" style="height: auto;"> <!-- Remove fixed height -->
                    
                    <?php echo $__env->make('partials._announcement', ['announcements' => $announcements], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <hr>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ePKU\resources\views\partials\_announcement.blade.php ENDPATH**/ ?>