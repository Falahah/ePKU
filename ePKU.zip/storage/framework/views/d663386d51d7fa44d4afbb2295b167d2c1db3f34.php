

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div>
        <div class="card" style="min-height: 70vh;">
            <div class="card-header text-white d-flex align-items-center justify-content-between">
                <span>Manage Medical Staff</span>
                <?php echo $__env->make('partials.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="text-center mt-3">
                <a href="<?php echo e(route('admin.addMedStaffForm')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Medical Staff
                </a>
            </div>

            <div class="card-body">
                <?php if(session('message')): ?>
                <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>                
            <ul class="nav nav-tabs" id="medStaffTabs" role="tablist">
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link<?php echo e($loop->first ? ' active' : ''); ?>" id="<?php echo e($department->name); ?>-tab" data-toggle="tab" href="#<?php echo e($department->name); ?>" role="tab" aria-controls="<?php echo e($department->name); ?>" aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"><?php echo e($department->name); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
                <div class="tab-content" id="medStaffTabsContent">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade<?php echo e($loop->first ? ' show active' : ''); ?>" id="<?php echo e($department->name); ?>" role="tabpanel" aria-labelledby="<?php echo e($department->name); ?>-tab">
                        <br>
                        <div class="mb-3">
                            <input type="text" id="<?php echo e($department->name); ?>UserSearch" class="form-control" placeholder="Search <?php echo e($department->name); ?> medical staff...">
                        </div>
                        <table class="table table-striped" id="<?php echo e($department->name); ?>MedicalStaffTable">
                            <thead>
                                <tr>
                                    <th class="text-center">MSID</th>
                                    <th class="text-center">Name</th>
                                    <th class="text-center">Gender</th>
                                    <th class="text-center">Email</th>
                                    <th class="text-center">Phone Number</th>
                                    <th class="text-center">Position</th>
                                    <th class="text-center">Unit</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                                <tbody>
                                    <?php $__currentLoopData = $department->medicalStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medStaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($medStaff->msID); ?></td>
                                            <td class="text-center"><?php echo e($medStaff->name); ?></td>
                                            <td class="text-center"><?php echo e($medStaff->gender); ?></td>
                                            <td class="text-center"><?php echo e($medStaff->email); ?></td>
                                            <td class="text-center"><?php echo e($medStaff->phone_number); ?></td>
                                            <td class="text-center"><?php echo e($medStaff->position); ?></td>
                                            <td class="text-center">
                                                <?php if($medStaff->unit): ?>
                                                    <?php echo e($medStaff->unit->name); ?>

                                                <?php else: ?>
                                                    <em>No Associated Units</em>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                            <span id="medStaffStatus"> 
                                                            <?php if($medStaff->active): ?>
                                                                <span class="text-success">Active</span>
                                                            <?php else: ?>
                                                                <span class="text-danger">Inactive</span>
                                                            <?php endif; ?>
                                                        </span>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('admin.medStaffDetails', ['medStaffId' => $medStaff->msID])); ?>" class="btn btn-info">
                                                    <i class="fas fa-info"></i>
                                                </a>
                                                <a href="<?php echo e(route('admin.editMedStaff', ['medStaffId' => $medStaff->msID])); ?>" class="btn btn-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="post" action="<?php echo e(route('admin.deleteMedStaff', ['medStaffId' => $medStaff->msID])); ?>" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this staff member?')">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('input[id$="UserSearch"]').on('input', function() {
            var searchText = $(this).val().toLowerCase();
            var tableId = $(this).attr('id').replace('UserSearch', 'MedicalStaffTable');
            var $tableRows = $('#' + tableId + ' tbody tr');

            $tableRows.show();
            $tableRows.filter(function() {
                return $(this).text().toLowerCase().indexOf(searchText) === -1;
            }).hide();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ePKU\resources\views\admin\manageMedStaff.blade.php ENDPATH**/ ?>