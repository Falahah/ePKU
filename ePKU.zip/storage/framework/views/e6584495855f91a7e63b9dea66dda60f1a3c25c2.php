

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="d-flex justify-content-between align-items-center">
        <ul class="nav nav-tabs" id="bookingHistoryTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link" id="upcoming-booking-tab" data-toggle="tab" href="#upcoming-booking" role="tab" aria-controls="upcoming-booking" aria-selected="false">Upcoming</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="completed-booking-tab" data-toggle="tab" href="#completed-booking" role="tab" aria-controls="completed-booking" aria-selected="false">Completed</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="cancelled-booking-tab" data-toggle="tab" href="#cancelled-booking" role="tab" aria-controls="cancelled-booking" aria-selected="false">Cancelled</a>
            </li>
        </ul>
        <br>
        <form method="GET" action="<?php echo e(route('booking-history')); ?>" class="col-md-8">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="filter_date">Sort by Date</label>
                        <select name="filter_date" id="filter_date" class="form-control">
                            <option value="earliest" <?php echo e($filterDate === 'earliest' ? 'selected' : ''); ?>>Earliest</option>
                            <option value="latest" <?php echo e($filterDate === 'latest' ? 'selected' : ''); ?>>Latest</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="filter_service">Filter by Service</label>
                        <select name="filter_service" id="filter_service" class="form-control">
                            <option value="">All Services</option>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service->service_type); ?>" <?php echo e($filterService === $service->service_type ? 'selected' : ''); ?>><?php echo e($service->service_type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply Filters</button>
                    <a href="<?php echo e(route('booking-history')); ?>" class="btn btn-secondary ml-2"><i class="fas fa-times"></i> Clear Filters</a>
                </div>
            </div>
        </form>
        <div>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Go Back</a>
        </div>
    </div>

    <div class="tab-content mt-2" id="bookingHistoryTabsContent">
        <div class="tab-pane fade" id="upcoming-booking" role="tabpanel" aria-labelledby="upcoming-booking-tab">
            <?php echo $__env->make('partials.booking-history-table', ['appointments' => $upcomingAppointments, 'tab' => 'upcoming'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="d-flex justify-content-center mt-3">
                <ul class="pagination">
                    <li class="page-item <?php echo e($upcomingAppointments->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($upcomingAppointments->url(1)); ?>" tabindex="-1">&lt;&lt;</a>
                    </li>
                    <li class="page-item <?php echo e($upcomingAppointments->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($upcomingAppointments->previousPageUrl()); ?>" tabindex="-1">&lt;</a>
                    </li>
                    <?php for($page = 1; $page <= $upcomingAppointments->lastPage(); $page++): ?>
                        <li class="page-item <?php echo e($upcomingAppointments->currentPage() == $page ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($upcomingAppointments->url($page)); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php echo e($upcomingAppointments->currentPage() == $upcomingAppointments->lastPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($upcomingAppointments->nextPageUrl()); ?>">&gt;</a>
                    </li>
                    <li class="page-item <?php echo e($upcomingAppointments->currentPage() == $upcomingAppointments->lastPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($upcomingAppointments->url($upcomingAppointments->lastPage())); ?>">&gt;&gt;</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="tab-pane fade" id="completed-booking" role="tabpanel" aria-labelledby="completed-booking-tab">
            <?php echo $__env->make('partials.booking-history-table', ['appointments' => $completedAppointments, 'tab' => 'completed'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="d-flex justify-content-center mt-3">
                <ul class="pagination">
                    <li class="page-item <?php echo e($completedAppointments->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($completedAppointments->url(1)); ?>" tabindex="-1">&lt;&lt;</a>
                    </li>
                    <li class="page-item <?php echo e($completedAppointments->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($completedAppointments->previousPageUrl()); ?>" tabindex="-1">&lt;</a>
                    </li>
                    <?php for($page = 1; $page <= $completedAppointments->lastPage(); $page++): ?>
                        <li class="page-item <?php echo e($completedAppointments->currentPage() == $page ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($completedAppointments->url($page)); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php echo e($completedAppointments->currentPage() == $completedAppointments->lastPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($completedAppointments->nextPageUrl()); ?>">&gt;</a>
                    </li>
                    <li class="page-item <?php echo e($completedAppointments->currentPage() == $completedAppointments->lastPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($completedAppointments->url($completedAppointments->lastPage())); ?>">&gt;&gt;</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="tab-pane fade" id="cancelled-booking" role="tabpanel" aria-labelledby="cancelled-booking-tab">
            <?php echo $__env->make('partials.booking-history-table', ['appointments' => $cancelledAppointments, 'tab' => 'cancelled'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="d-flex justify-content-center mt-3">
                <ul class="pagination">
                    <li class="page-item <?php echo e($cancelledAppointments->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($cancelledAppointments->url(1)); ?>" tabindex="-1">&lt;&lt;</a>
                    </li>
                    <li class="page-item <?php echo e($cancelledAppointments->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($cancelledAppointments->previousPageUrl()); ?>" tabindex="-1">&lt;</a>
                    </li>
                    <?php for($page = 1; $page <= $cancelledAppointments->lastPage(); $page++): ?>
                        <li class="page-item <?php echo e($cancelledAppointments->currentPage() == $page ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($cancelledAppointments->url($page)); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php echo e($cancelledAppointments->currentPage() == $cancelledAppointments->lastPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($cancelledAppointments->nextPageUrl()); ?>">&gt;</a>
                    </li>
                    <li class="page-item <?php echo e($cancelledAppointments->currentPage() == $cancelledAppointments->lastPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($cancelledAppointments->url($cancelledAppointments->lastPage())); ?>">&gt;&gt;</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const activeTab = localStorage.getItem('activeTab');
        if (activeTab) {
            const tabElement = document.querySelector(`#${activeTab}-tab`);
            if (tabElement) {
                document.querySelectorAll('#bookingHistoryTabs .nav-link').forEach(tab => tab.classList.remove('active'));
                document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('show', 'active'));

                tabElement.classList.add('active');
                document.querySelector(`#${activeTab}`).classList.add('show', 'active');
            }
        } else {
            document.querySelector('#upcoming-booking-tab').classList.add('active');
            document.querySelector('#upcoming-booking').classList.add('show', 'active');
        }

        const tabLinks = document.querySelectorAll('#bookingHistoryTabs .nav-link');
        tabLinks.forEach(tab => {
            tab.addEventListener('click', function () {
                localStorage.setItem('activeTab', this.getAttribute('aria-controls'));
            });
        });

        // Sorting functionality
        const getSortOrder = () => localStorage.getItem('sortOrder') || 'asc';
        const setSortOrder = (order) => localStorage.setItem('sortOrder', order);
        const getSortColumn = () => localStorage.getItem('sortColumn') || 'appointment_id';
        const setSortColumn = (column) => localStorage.setItem('sortColumn', column);

        const sortTable = (column) => {
            const sortOrder = getSortOrder();
            const table = document.querySelector('.tab-pane.show .table tbody');
            const rows = Array.from(table.rows);

            rows.sort((a, b) => {
                let cellA = a.querySelector(`td[data-sort="${column}"]`).innerText.toLowerCase();
                let cellB = b.querySelector(`td[data-sort="${column}"]`).innerText.toLowerCase();

                if (column === 'date') {
                    // Extract month and year for comparison
                    const dateA = new Date(cellA.split('/').reverse().join('/'));
                    const dateB = new Date(cellB.split('/').reverse().join('/'));

                    const monthA = dateA.getMonth();
                    const yearA = dateA.getFullYear();
                    const monthB = dateB.getMonth();
                    const yearB = dateB.getFullYear();

                    if (yearA === yearB) {
                        return (monthA < monthB ? -1 : (monthA > monthB ? 1 : 0)) * (sortOrder === 'asc' ? 1 : -1);
                    } else {
                        return (yearA < yearB ? -1 : (yearA > yearB ? 1 : 0)) * (sortOrder === 'asc' ? 1 : -1);
                    }
                }

                return (cellA < cellB ? -1 : (cellA > cellB ? 1 : 0)) * (sortOrder === 'asc' ? 1 : -1);
            });

            table.innerHTML = '';
            rows.forEach(row => table.appendChild(row));
        };

        document.querySelectorAll('.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const column = th.dataset.sort;
                const currentOrder = getSortOrder();
                const newOrder = currentOrder === 'asc' ? 'desc' : 'asc';
                setSortOrder(newOrder);
                setSortColumn(column);
                sortTable(column);

                document.querySelectorAll('.sortable').forEach(th => th.classList.remove('asc', 'desc'));
                th.classList.add(newOrder);
            });
        });

        // Initial sort
        sortTable(getSortColumn());
    });
</script>

<?php $__env->stopSection(); ?>

<style>
    .completed {
        color: green;
    }

    .upcoming {
        color: orange;
    }

    .cancelled {
        color: red;
    }

    th.sortable {
        cursor: pointer;
    }

    th.sortable.asc::after {
        content: ' ▲';
    }

    th.sortable.desc::after {
        content: ' ▼';
    }
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ePKU\resources\views\appointments\booking-history.blade.php ENDPATH**/ ?>