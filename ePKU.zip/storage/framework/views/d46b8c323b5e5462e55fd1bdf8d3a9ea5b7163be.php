
<?php $__env->startSection('content'); ?>
<style>
    .card-header {
        background-color: #007bff;
        color: white;
        font-size: 1.25rem;
        position: relative;
    }
    .info-icon {
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
    }
    .info-tooltip {
        display: none;
        position: absolute;
        font-size: 1rem;
        top: 30px;
        right: 10px;
        background-color: rgba(0, 0, 0, 0.7);
        color: white;
        padding: 10px;
        border-radius: 5px;
        width: 250px;
        z-index: 1;
    }
    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
    }
    .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
    }
    .card {
        border-radius: 16px;
    }
    .card-body {
        padding: 2rem;
    }
    .form-floating {
        margin-bottom: 1rem;
    }
    .position-relative {
        position: relative;
    }

    .position-absolute {
        position: absolute;
    }

</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header">
                    <?php echo e(__('User Profile')); ?>

                    <i class="fas fa-info-circle info-icon"></i>
                    <div class="info-tooltip">
                        Other personal details are not editable since they are registered under UTHM.<br>You may only edit your phone number.
                    </div>
                </div>

                <div class="card-body">
                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="row gy-3">
                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="name" value="<?php echo e($user->name); ?>" readonly>
                                <label for="name">Name</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="username" value="<?php echo e($user->username); ?>" readonly>
                                <label for="username">Username</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="ic" value="<?php echo e($user->IC); ?>" readonly>
                                <label for="ic">IC</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="dob" value="<?php echo e($user->date_of_birth); ?>" readonly>
                                <label for="dob">Date of Birth</label>
                            </div>
                        </div>
                
                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="gender" value="<?php echo e($user->gender); ?>" readonly>
                                <label for="gender">Gender</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="role" value="<?php echo e($user->role); ?>" readonly>
                                <label for="role">Status (Role)</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" id="email" value="<?php echo e($user->email); ?>" readonly>
                                <label for="email">Email</label>
                            </div>

                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="phone-number" value="<?php echo e($user->phone_number); ?>" readonly>
                                <label for="phone-number">Phone Number</label>
                                <div class="position-relative">
                                    <?php if($editable): ?>
                                    <button id="edit-btn" class="btn btn-sm btn-primary ml-2 position-absolute top-0 end-0 translate-middle-y" style="font-size: 1.2rem;">                                                
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php endif; ?> 
                                </div>
                            </div>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">                        
                                <i class="fas fa-arrow-left"></i> Go Back
                            </a>
                            <a href="<?php echo e(route('change-password')); ?>" class="btn btn-primary">                         
                                <i class="fas fa-key"></i> Change Password
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var editable = <?php echo json_encode($editable, 15, 512) ?>;

    document.addEventListener('DOMContentLoaded', function () {
        const editBtn = document.getElementById('edit-btn');
        const phoneNumber = document.getElementById('phone-number');
        const infoIcon = document.querySelector('.info-icon');
        const infoTooltip = document.querySelector('.info-tooltip');

        function handleEdit() {
            phoneNumber.removeAttribute('readonly');
            phoneNumber.focus();
            editBtn.innerHTML = '<i class="fas fa-save"></i>';
            editBtn.classList.remove('btn-primary');
            editBtn.classList.add('btn-success');

            editBtn.removeEventListener('click', handleEdit);
            editBtn.addEventListener('click', handleSubmit);
        }

        function handleSubmit() {
            if (confirm('Confirm to edit phone number?')) {
                const phoneNumberValue = phoneNumber.value;
                fetch('<?php echo e(route('update-phone')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({ phone_number: phoneNumberValue })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        phoneNumber.setAttribute('readonly', 'readonly');
                        editBtn.innerHTML = '<i class="fas fa-edit"></i>';
                        editBtn.classList.remove('btn-success');
                        editBtn.classList.add('btn-primary');

                        const successAlert = document.createElement('div');
                        successAlert.classList.add('alert', 'alert-success');
                        successAlert.textContent = 'Phone number updated successfully';
                        const cardBody = document.querySelector('.card-body');
                        cardBody.insertBefore(successAlert, cardBody.firstChild);
                    } else {
                        alert('Failed to update phone number');
                    }
                })
                .catch(error => console.error('Error:', error));
            }
        }

        if (editable && editBtn) {
            editBtn.addEventListener('click', handleEdit);
        }

        if (infoIcon) {
            infoIcon.addEventListener('mouseover', function () {
                infoTooltip.style.display = 'block';
            });

            infoIcon.addEventListener('mouseout', function () {
                infoTooltip.style.display = 'none';
            });
        }

        const otherPersonalDetailsInputs = document.querySelectorAll('.form-floating:not(:last-of-type) input');
        otherPersonalDetailsInputs.forEach(input => {
            input.addEventListener('click', function () {
                const popup = document.createElement('div');
                popup.classList.add('alert', 'alert-warning', 'position-absolute', 'start-50', 'top-50', 'translate-middle-x', 'text-center');
                popup.style.zIndex = '2';
                popup.innerHTML = 'Other personal details are <br><strong>not editable</strong> since they are registered under UTHM.<br>You may only edit your <strong>phone number.</strong>';
                document.querySelector('.card-body').appendChild(popup);
                // Remove the popup after 3 seconds
                setTimeout(() => {
                    popup.remove();
                }, 3000);
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ePKU\resources\views\profile.blade.php ENDPATH**/ ?>