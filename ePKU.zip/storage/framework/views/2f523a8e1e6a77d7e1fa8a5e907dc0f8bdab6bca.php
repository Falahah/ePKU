

<?php $__env->startSection('content'); ?>

<style>
    .upcoming {
        color: orange;
        font-weight: bold;
    }
    .completed {
        color: green;
        font-weight: bold;
    }
    .cancelled {
        color: red;
        font-weight: bold;
    }
    .stars {
        font-size: 24px;
    }
    .star {
        color: #ccc;
    }
    .star.selected {
        color: gold;
    }
</style>

<div class="row justify-content-center">
    <div>
        <div class="card">
            <div class="card-header text-white d-flex align-items-center justify-content-between">
                <span>Appointment Details</span>
                <?php echo $__env->make('partials.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include the tabs partial -->
            </div>
            <div class="card-body">
                <div class="mx-auto d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(route('admin.manageAppointments')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i>
                    </a> 
                    <h2 class="text-center text-primary"><strong>Appointment Details</strong></h2><br>
                </div><br>

                <!-- Check for success message and display it -->
                <?php if(session('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>

                <table class="table table-striped table-bordered">
                    <tbody>
                        <tr>
                            <th>Appointment ID</th>
                            <td><?php echo e($appointment->appointment_id); ?></td>
                        </tr>
                        <tr>
                            <th>Service</th>
                            <td><?php echo e($appointment->selected_service_type); ?></td>
                        </tr>
                        <tr>
                            <th>Date</th>
                            <td><?php echo e(\Carbon\Carbon::parse($appointment->date)->format('d/m/Y')); ?></td>
                        </tr>
                        <tr>
                            <th>Time</th>
                            <td><?php echo e($appointment->timeSlot ? \Carbon\Carbon::parse($appointment->timeSlot->start_time)->format('h:i A') : 'Not available'); ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td style="
                                color: <?php echo e($appointment->appointment_status == 'upcoming' ? 'orange' : ''); ?>;
                                color: <?php echo e($appointment->appointment_status == 'completed' ? 'green' : ''); ?>;
                                color: <?php echo e($appointment->appointment_status == 'cancelled' ? 'red' : ''); ?>;
                                font-weight: bold;">
                                <?php echo e(ucfirst($appointment->appointment_status)); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>Feedback</th>
                            <td>
                                <?php if($appointment->appointment_status === 'completed'): ?>
                                    <em><?php echo e($appointment->feedbackRating ? $appointment->feedbackRating->feedback : 'Not available'); ?></em>
                                <?php elseif($appointment->appointment_status === 'upcoming'): ?>
                                    <em>Feedback will be available after the appointment.</em>
                                <?php elseif($appointment->appointment_status === 'cancelled'): ?>
                                    <em>Feedback is not available since the appointment is cancelled.</em>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Rating</th>
                            <td>
                                <?php if($appointment->appointment_status === 'completed' && $appointment->feedbackRating): ?>
                                    <span class="stars">
                                        <?php
                                            $rating = $appointment->feedbackRating->rating;
                                            $filledStars = min(5, $rating);
                                            $emptyStars = max(0, 5 - $rating);
                                        ?>
                                        <?php for($i = 0; $i < $filledStars; $i++): ?>
                                            <span class="star selected">&#9733;</span>
                                        <?php endfor; ?>
                                        <?php for($i = 0; $i < $emptyStars; $i++): ?>
                                            <span class="star">&#9733;</span>
                                        <?php endfor; ?>
                                    </span>
                                <?php else: ?>
                                    <?php if($appointment->appointment_status === 'completed'): ?>
                                        <em>Not available</em>
                                    <?php elseif($appointment->appointment_status === 'upcoming'): ?>
                                        <em>Rating will be available after the appointment.</em>
                                    <?php elseif($appointment->appointment_status === 'cancelled'): ?>
                                        <em>Rating is not available since the appointment is cancelled.</em>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if($appointment->appointment_status === 'upcoming'): ?>
                            <tr>
                                <th>Assigned Medical Staff</th>
                                <td>
                                    <div id="assigned-staff-section">
                                        <?php if($appointment->msID): ?>
                                            <?php echo e(optional($appointment->medicalStaff)->name); ?>

                                            <button id="reassign-button" class="btn btn-warning btn-sm ml-2">Re-Assign</button>
                                        <?php else: ?>
                                            <form method="POST" action="<?php echo e(route('admin.assignMedStaff', ['appointmentId' => $appointment->appointment_id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <label for="msID">Select Medical Staff:</label>
                                                    <select name="msID" id="msID" class="form-control" required>
                                                        <option value="">-- Select Medical Staff --</option>
                                                        <?php $__currentLoopData = $medicalStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($staff->msID); ?>" <?php echo e($appointment->msID == $staff->msID ? 'selected' : ''); ?>>
                                                                <?php echo e($staff->name); ?> (<?php echo e($staff->position); ?>)
                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Assign</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                    <div id="reassign-section" style="display: none;">
                                        <form method="POST" action="<?php echo e(route('admin.assignMedStaff', ['appointmentId' => $appointment->appointment_id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="msID">Select Medical Staff:</label>
                                                <select name="msID" id="msID" class="form-control" required>
                                                    <option value="">-- Select Medical Staff --</option>
                                                    <?php $__currentLoopData = $medicalStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($staff->msID); ?>" <?php echo e($appointment->msID == $staff->msID ? 'selected' : ''); ?>>
                                                            <?php echo e($staff->name); ?> (<?php echo e($staff->position); ?>)
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Assign</button>
                                            <button type="button" id="cancel-reassign-button" class="btn btn-secondary">Cancel</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var reassignButton = document.getElementById('reassign-button');
        var reassignSection = document.getElementById('reassign-section');
        var assignedStaffSection = document.getElementById('assigned-staff-section');
        var cancelReassignButton = document.getElementById('cancel-reassign-button');

        if (reassignButton) {
            reassignButton.addEventListener('click', function () {
                assignedStaffSection.style.display = 'none';
                reassignSection.style.display = 'block';
            });
        }

        if (cancelReassignButton) {
            cancelReassignButton.addEventListener('click', function () {
                reassignSection.style.display = 'none';
                assignedStaffSection.style.display = 'block';
            });
        }
    });

    // Function to set the active tab based on the current URL
    $(document).ready(function () {
        var currentPath = window.location.pathname;
        if (currentPath.includes('/admin/booking-details')) {
            $('.nav-link[data-tab="manageAppointments"]').addClass('active');
        } else {
            $('.nav-link').each(function () {
                var link = $(this).attr('href');
                if (currentPath === link) {
                    $(this).addClass('active');
                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ePKU\resources\views\admin\booking-details.blade.php ENDPATH**/ ?>