import './bootstrap';
// resources/js/app.js

require('./bootstrap');
require('bootstrap'); // Add this line to import Bootstrap
